package com.example.fyp_screens;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.ml.common.FirebaseMLException;
import com.google.firebase.ml.common.modeldownload.FirebaseModelDownloadConditions;
import com.google.firebase.ml.common.modeldownload.FirebaseModelManager;
import com.google.firebase.ml.custom.FirebaseCustomRemoteModel;
import com.google.firebase.ml.custom.FirebaseModelDataType;
import com.google.firebase.ml.custom.FirebaseModelInputOutputOptions;
import com.google.firebase.ml.custom.FirebaseModelInterpreter;
import com.google.firebase.ml.custom.FirebaseModelInterpreterOptions;

import static android.content.ContentValues.TAG;


public class lstmClassifier {
    private FirebaseModelInterpreter interpreter;
    private FirebaseModelInputOutputOptions dataOptions;

    public lstmClassifier(final Context context) throws FirebaseMLException {
        final FirebaseCustomRemoteModel remoteModel =
                new FirebaseCustomRemoteModel.Builder("offense-detector").build();
        final FirebaseModelManager firebaseModelManager = FirebaseModelManager.getInstance();
        firebaseModelManager
                .isModelDownloaded(remoteModel)
                .continueWithTask(
                        new Continuation<Boolean, Task<Void>>() {
                            @Override
                            public Task<Void> then(@NonNull Task<Boolean> task) throws Exception {
                                // Create update condition if model is already downloaded,
                                // otherwise create download
                                // condition.
                                FirebaseModelDownloadConditions conditions =
                                        task.getResult()
                                                ? new FirebaseModelDownloadConditions.Builder()
                                                .requireWifi()
                                                .build() // Update condition that requires wifi.
                                                : new FirebaseModelDownloadConditions.Builder()
                                                .build(); // Download condition.
                                return firebaseModelManager.download(remoteModel, conditions);
                            }
                        })
                .addOnSuccessListener(
                        new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void ignored) {
                                FirebaseModelInterpreterOptions interpreterOptions =
                                        new FirebaseModelInterpreterOptions.Builder(
                                                new FirebaseCustomRemoteModel.Builder("offense-detector").build())
                                                .build();
                                try {
                                    interpreter =
                                            FirebaseModelInterpreter.getInstance(interpreterOptions);
                                    Log.e(TAG, "succed  to build FirebaseModelInterpreter. ");

                                } catch (FirebaseMLException e) {
                                    Log.e(TAG, "Failed to build FirebaseModelInterpreter. ", e);
                                }
                            }
                        })
                .addOnFailureListener(
                        new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception ignored) {
                                Toast.makeText(
                                        context,
                                        "Model download failed for image classifier, please check" +
                                                " your connection.",
                                        Toast.LENGTH_LONG)
                                        .show();
                            }
                        });


        Log.d(TAG, "Created a Custom Image Classifier.");
        int[] inputDims = {1, 200};
        int[] outputDims = {1,1};


        dataOptions =
                new FirebaseModelInputOutputOptions.Builder()
                        .setInputFormat(0, FirebaseModelDataType.INT32, inputDims)
                        .setOutputFormat(0, FirebaseModelDataType.FLOAT32, outputDims)
                        .build();
        Log.d(TAG, "Configured input & output data for the custom image classifier.");
    }//constructor
}
