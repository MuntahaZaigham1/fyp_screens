package com.example.fyp_screens;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.widget.Button;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.ml.common.FirebaseMLException;
import com.google.firebase.ml.common.modeldownload.FirebaseModelDownloadConditions;
import com.google.firebase.ml.common.modeldownload.FirebaseModelManager;
import com.google.firebase.ml.common.modeldownload.FirebaseRemoteModel;
import com.google.firebase.ml.custom.FirebaseCustomRemoteModel;

import org.tensorflow.lite.Interpreter;

import java.io.File;

import static java.lang.Thread.sleep;

//import com.example.fyp_screens.global;
public class HomeScreen extends AppCompatActivity {
    private lstmClassifier classifier;
    /*
    Interpreter interpreter;
    public void onStart() {
        super.onStart();
        global.flag++;
        Toast.makeText(HomeScreen.this, "111111111111111111111111model download Successful.",Toast.LENGTH_SHORT).show();

        FirebaseCustomRemoteModel remoteModel =
                new FirebaseCustomRemoteModel.Builder("offense-detector").build();
        FirebaseModelDownloadConditions conditions = new FirebaseModelDownloadConditions.Builder()
                .requireWifi()
                .build();
        Toast.makeText(HomeScreen.this, "222222221model download Successful.",Toast.LENGTH_SHORT).show();
        if(global.flag==1) {
            FirebaseModelManager.getInstance().download(remoteModel, conditions)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void v) {
                            // Download complete. Depending on your app, you could enable
                            // the ML feature, or switch from the local model to the remote
                            // model, etc.

                            Toast.makeText(HomeScreen.this, "model download Successful.", Toast.LENGTH_SHORT).show();

                        }
                    });
                }
                else{
                    //do nothing

            FirebaseModelManager.getInstance().getLatestModelFile(remoteModel)
                    .addOnCompleteListener(new OnCompleteListener<File>() {
                        @Override
                        public void onComplete(@NonNull Task<File> task) {
                            File modelFile = task.getResult();
                            if (modelFile != null) {
                                Toast.makeText(HomeScreen.this, "model343434 download Successful.",Toast.LENGTH_SHORT).show();

                                interpreter = new Interpreter(modelFile);
                            }
                            else Toast.makeText(HomeScreen.this, "failed.",Toast.LENGTH_SHORT).show();

                        }
                    });
            Toast.makeText(HomeScreen.this, "333333333333model download Successful.",Toast.LENGTH_SHORT).show();
                }

    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home_screen);
        Button off,cat,tar,logout;
        off=findViewById(R.id.button);
        cat=findViewById(R.id.button1);
        tar=findViewById(R.id.button2);
        logout=findViewById(R.id.button4);
        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tweet;

                tweet=findViewById(R.id.editText);
                final String text;
                text=tweet.getText().toString();
                Intent i = new Intent(getApplicationContext(), result1.class);

                try {
                    classifier=new lstmClassifier(getApplicationContext());
                } catch (FirebaseMLException e) {
                    e.printStackTrace();
                }

                global.bid=1;
                i.putExtra("tweet",text);
                startActivity(i);
            }
        });
        cat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tweet;

                tweet=findViewById(R.id.editText);
                final String text;
                text=tweet.getText().toString();
                Intent i = new Intent(getApplicationContext(), result1.class);
                global.bid=2;
                i.putExtra("tweet",text);
                startActivity(i);
            }
        });
        tar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tweet;

                tweet=findViewById(R.id.editText);
                final String text;
                text=tweet.getText().toString();
                Intent i = new Intent(getApplicationContext(), result1.class);
                global.bid=3;
                i.putExtra("tweet",text);
                startActivity(i);
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });
    }
}
