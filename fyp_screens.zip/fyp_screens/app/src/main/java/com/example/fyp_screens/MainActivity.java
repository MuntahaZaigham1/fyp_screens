package com.example.fyp_screens;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import org.w3c.dom.Text;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    EditText email,password;
    private FirebaseAuth mAuth;
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser!=null) {
            Intent i = new Intent(getApplicationContext(), HomeScreen.class);
            startActivity(i);
        }
        //updateUI(currentUser);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button but;

        but = findViewById(R.id.button);
        mAuth = FirebaseAuth.getInstance();
        password=findViewById(R.id.editText2);
        email=findViewById(R.id.editText);

        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email1=email.getText().toString().trim();
                String password1=password.getText().toString().trim();
                if(TextUtils.isEmpty(email1)){
                    email.setError("Email is required");
                    return;
                }
                if(TextUtils.isEmpty(password1)){
                    password.setError("Password is required");
                    return;
                }
                if(password1.length()<=4){
                    password.setError("Enter password of length greater than 4");
                    return;
                }
                mAuth.signInWithEmailAndPassword(email1, password1)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    //Log.d("signInWithEmail:success");
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    Toast.makeText(MainActivity.this, "Authentication Successful.",Toast.LENGTH_SHORT).show();
                                    Intent i = new Intent(getApplicationContext(), HomeScreen.class);
                                    startActivity(i);
                                } else {

                                    Toast.makeText(MainActivity.this, "Authentication failed.",Toast.LENGTH_SHORT).show();

                                }

                                // ...
                            }
                        });
                //Intent i = new Intent(getApplicationContext(), HomeScreen.class);
                //startActivity(i);
            }
        });

        TextView reg;
        reg  =  findViewById(R.id.textView2);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), register.class);
                startActivity(i);
            }
        });

    }
}
