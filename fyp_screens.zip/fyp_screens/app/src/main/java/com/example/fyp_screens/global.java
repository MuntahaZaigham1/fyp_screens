package com.example.fyp_screens;

public class global {
    public static int bid;
    public static int flag=0;

}
